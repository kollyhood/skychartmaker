import fs from 'fs'
import os from 'os'
import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const maxDuration = 60

/**
 * Grid Hunter — VLM-based layout detection.
 *
 * The classical Grid Definer (contour detection: edges -> threshold ->
 * morphological close -> connected components) works well on flyers with a
 * handful of large, clearly-separated blocks. It falls apart on dense
 * "small multiples" grids (e.g. a supermarket price board with 15-20
 * near-identical product cells) — the close step fuses adjacent cells
 * with similar content/background into a handful of oversized blobs.
 *
 * A vision-language model can instead reason about the *repeating
 * structure* directly ("this is a grid of N product cells, each with an
 * image, a name, and a price"), which is a much better fit for that class
 * of image. This endpoint asks the VLM for that structure directly and
 * returns House-shaped geometry. It is tried first by the client; if it's
 * unavailable (no key) or returns nothing usable, the client falls back to
 * the client-side Grid Definer.
 */
function hasZaiCredentials(): boolean {
  if (process.env.ZAI_API_KEY) return true
  const candidates = ['./.z-ai-config', `${os.homedir()}/.z-ai-config`, '/etc/.z-ai-config']
  return candidates.some((p) => {
    try {
      return fs.existsSync(p)
    } catch {
      return false
    }
  })
}

interface RawCell {
  kind?: string
  label?: string
  bbox?: { x?: number; y?: number; w?: number; h?: number }
}

export async function POST(req: NextRequest) {
  try {
    const { image } = (await req.json()) as { image?: string }
    if (!image || !image.startsWith('data:')) {
      return NextResponse.json({ error: 'Missing image data URL' }, { status: 400 })
    }

    if (!hasZaiCredentials()) {
      return NextResponse.json({
        houses: [],
        skipped: true,
        message:
          'Grid Hunter is not configured (no ZAI_API_KEY / .z-ai-config found). Falling back to contour-based detection.',
      })
    }

    const zai = await ZAI.create()
    const prompt = `You are a layout analysis engine ("Grid Hunter") for retail price-board flyers.

These images are often a GRID of repeating product cells — each cell has a product photo, a product name (may be in a regional language), a price, and a unit (kg/pcs/etc). There is also usually a header banner and sometimes a footer strip.

Identify every distinct layout cell in the image. For each cell, return:
- "kind": one of "text" (a text-only block: headline, price label, footer strip), "image" (a product photo area), or "spacer" (decorative divider/banner with no reusable content)
- "label": a short human label, e.g. "Product cell 3", "Header banner", "Footer strip"
- "bbox": PERCENTAGES of image dimensions (0-100), keys "x", "y", "w", "h", where (x+w) <= 100 and (y+h) <= 100.

Guidance:
- If this is a product grid, return ONE cell per product (not one giant box for the whole grid) — a typical grid has 6 to 24 cells.
- Prefer more, smaller, accurate cells over fewer, larger, imprecise ones.
- Each product cell is usually a single "image" kind box covering the photo+name+price together (the app's own manual editor is used to subdivide further) UNLESS the name/price is clearly a separate text strip below the photo, in which case return an "image" cell for the photo and a "text" cell for the name/price strip.
- Include the header banner as one "text" or "spacer" cell, and a footer strip if present.

Return STRICT JSON only — no markdown fences, no prose. Schema:
{ "cells": [ { "kind": "image", "label": "Product cell 1", "bbox": { "x": 5, "y": 20, "w": 22, "h": 15 } } ] }

Maximum 24 cells. If you cannot find a clear grid structure, return { "cells": [] }.`

    const response = await zai.chat.completions.createVision({
      model: 'glm-4.6v',
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'image_url', image_url: { url: image } },
          ],
        },
      ],
      thinking: { type: 'disabled' },
    })

    const content = response.choices[0]?.message?.content ?? ''
    const cleaned = content.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim()

    let parsed: { cells?: RawCell[] }
    try {
      parsed = JSON.parse(cleaned)
    } catch {
      const match = cleaned.match(/\{[\s\S]*\}/)
      if (!match) {
        return NextResponse.json(
          { error: 'Grid Hunter returned unparseable output', raw: content },
          { status: 502 },
        )
      }
      try {
        parsed = JSON.parse(match[0])
      } catch {
        return NextResponse.json(
          { error: 'Grid Hunter returned malformed JSON', raw: content },
          { status: 502 },
        )
      }
    }

    const cells = Array.isArray(parsed.cells) ? parsed.cells : []

    const houses = cells
      .filter((c) => c && typeof c === 'object' && c.bbox)
      .map((c, i) => {
        const b = c.bbox as Record<string, unknown>
        const num = (v: unknown) => (typeof v === 'number' ? v : typeof v === 'string' ? parseFloat(v) : NaN)
        const x = clampPct(num(b.x))
        const y = clampPct(num(b.y))
        const w = clampPct(num(b.w))
        const h = clampPct(num(b.h))
        const kind = c.kind === 'text' || c.kind === 'image' || c.kind === 'spacer' ? c.kind : 'image'
        const label = typeof c.label === 'string' && c.label.trim() ? c.label.trim() : `Cell ${i + 1}`
        return { x, y, w, h, kind, label }
      })
      .filter((h) => h.w > 0 && h.h > 0)
      .slice(0, 24)

    return NextResponse.json({ houses })
  } catch (err) {
    console.error('[grid-hunt] error:', err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Unknown error' },
      { status: 500 },
    )
  }
}

function clampPct(v: unknown): number {
  const n = typeof v === 'number' ? v : 0
  if (!Number.isFinite(n)) return 0
  return Math.max(0, Math.min(100, n))
}
